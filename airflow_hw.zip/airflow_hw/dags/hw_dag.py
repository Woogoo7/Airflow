import datetime as dt
import os
import sys
from airflow.models import DAG
from airflow.operators.python import PythonOperator


# Указываем путь к директории с проектом
path = os.path.expanduser('~/airflow_hw')

# Добавляем путь к коду проекта в переменную окружения,
# чтобы он был доступен для python-процесса
os.environ['PROJECT_PATH'] = path

# Добавляем путь к коду проекта в $PATH, чтобы импортировать функции
sys.path.insert(0, path)

from modules.pipeline import pipeline
from modules.predict import predict

# Задаем аргументы для DAG
args = {
    'owner': 'airflow',
    'start_date': dt.datetime(2024, 5, 11),
    'retries': 1,
    'retry_delay': dt.timedelta(minutes=1),
    'depends_on_past': False,
}

# Создаем DAG
with DAG(
        dag_id='car_price_prediction',
        schedule_interval="00 15 * * *",  # Запускать ежедневно в 15:00
        default_args=args,
) as dag:
    # Создаем задачу pipeline
    pipeline_task = PythonOperator(
        task_id='pipeline',  # Идентификатор задачи
        python_callable=pipeline,  # Вызываемая функция
        dag=dag,
    )

    # Создаем задачу predict
    predict_task = PythonOperator(
        task_id='predict',  # Идентификатор задачи
        python_callable=predict,  # Вызываемая функция
        dag=dag,
    )

    # Определяем зависимости между задачами
    pipeline_task >> predict_task
